export default {
  MuiButtonGroup: {
    styleOverrides: {
      root: {
        borderRadius: 8
      }
    }
  }
}
