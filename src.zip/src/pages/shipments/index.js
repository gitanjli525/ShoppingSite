import React from 'react'

function shipments() {
  return (
    <>
      <div>shipments</div>
    </>
  )
}

export default shipments
