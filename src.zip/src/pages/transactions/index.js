import React from 'react'

function transactions() {
  return (
    <>
      <div>transactions</div>
    </>
  )
}

export default transactions
